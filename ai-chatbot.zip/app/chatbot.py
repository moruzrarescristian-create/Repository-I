import random,json
try:
 import joblib
 model=joblib.load('app/model.pkl')
 vectorizer=joblib.load('app/vectorizer.pkl')
except:
 model=None
 vectorizer=None
with open('app/intents.json') as f:
 intents=json.load(f)
def get_response(message):
 if model and vectorizer:
  pred=model.predict(vectorizer.transform([message]))[0]
  for i in intents['intents']:
   if i['tag']==pred:return random.choice(i['responses'])
 return 'Sorry, I do not understand.'
