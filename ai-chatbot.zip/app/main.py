from fastapi import FastAPI
from pydantic import BaseModel
from app.chatbot import get_response
app=FastAPI()
class ChatRequest(BaseModel):
    message:str
@app.post('/chat')
def chat(req:ChatRequest):
    return {'response':get_response(req.message)}
