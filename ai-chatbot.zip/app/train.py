import json,joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
with open('app/intents.json') as f:data=json.load(f)
X=[];y=[]
for i in data['intents']:
 for p in i['patterns']:
  X.append(p);y.append(i['tag'])
vec=TfidfVectorizer();Xt=vec.fit_transform(X)
model=LogisticRegression();model.fit(Xt,y)
joblib.dump(model,'app/model.pkl');joblib.dump(vec,'app/vectorizer.pkl')
