# Secure Cloud System

A Python-based secure cloud system designed to protect user data against SQL injection attacks and other common vulnerabilities. This project implements enterprise-grade security features including AES-256 encryption, capability-based access control tokens, and comprehensive audit logging.

## Architecture Overview

The system is built using **Flask** and **SQLite** for lightweight, efficient deployment. It follows a layered security architecture with multiple defense mechanisms:

### Core Components

- **Security Module** (`security.py`): Handles AES-256-GCM encryption/decryption with unique IVs per record, Argon2 password hashing, and capability token generation/validation/revocation with HMAC-SHA256 signatures.
- **Database Module** (`database.py`): Manages SQLite database initialization and provides connection utilities. All queries use parameterized statements to prevent SQL injection.
- **CRUD Operations** (`crud.py`): Implements Create, Read, Update, Delete operations for users, tokens, audit logs, and encrypted data vault records with full parameterization.
- **Flask API** (`main.py`): RESTful endpoints for user authentication, data vault operations, security dashboard management, and SQL injection demonstration.

### Security Layers

| Layer | Mechanism | Implementation |
|-------|-----------|-----------------|
| **Input Validation** | Sanitization and validation | Regex-based filtering in demo endpoint |
| **Parameterized Queries** | SQL injection prevention | All database queries use `?` placeholders with bound parameters |
| **Capability Tokens** | Access control | Scoped, short-lived, revocable tokens with HMAC-SHA256 signatures |
| **Encryption at Rest** | Data confidentiality | AES-256-GCM with unique 12-byte IV per record |
| **Password Hashing** | Credential protection | Argon2 with automatic salt generation |
| **Audit Logging** | Accountability | Records user, token, timestamp, operation, and outcome |

## Features

- **AES-256 Encryption**: Secure storage of sensitive information with unique initialization vectors (IVs) per record for maximum security.
- **Capability-Token Mechanism**: Scoped, short-lived (default 1 hour), and revocable tokens for granular access control. Tokens are hashed before storage using SHA-256.
- **Double-Layer SQL Injection Protection**:
  - **Layer 1 - Input Validation**: Filters and sanitizes incoming data.
  - **Layer 2 - Parameterized Queries**: All SQL queries use parameterized statements; no raw or dynamic SQL is executed anywhere.
- **Secure Data Vault**: Encrypted storage and retrieval of user records with automatic encryption/decryption.
- **Security Dashboard**: Web API for token management (create, list, revoke) and audit log viewing.
- **SQL Injection Demo**: Endpoint that demonstrates the system's resilience against SQL injection attempts.
- **Comprehensive Audit Logging**: Tracks all security-relevant actions with user ID, token ID, timestamp, operation type, and outcome.

## Project Structure

```
secure_cloud_system/
├── main.py              # Flask application with all API endpoints
├── config.py            # Configuration settings (SECRET_KEY, DATABASE_PATH, etc.)
├── database.py          # Database initialization and connection utilities
├── security.py          # Encryption, token management, and hashing functions
├── models.py            # Data structures (User, CapabilityToken, AuditLog, DataVaultRecord)
├── crud.py              # CRUD operations with parameterized SQL queries
├── requirements.txt     # Python dependencies
└── README.md            # This file
```

## Setup and Installation

### Prerequisites

- Python 3.8 or higher
- pip (Python package installer)

### Step 1: Clone the Repository

```bash
git clone <repository_url>
cd secure_cloud_system
```

### Step 2: Create a Virtual Environment

```bash
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 4: Initialize the Database

```bash
python3 database.py
```

This creates the SQLite database with the following tables:
- `users`: Stores user credentials (hashed passwords)
- `capability_tokens`: Stores hashed capability tokens with scopes and expiration times
- `audit_logs`: Records all security-relevant operations
- `data_vault`: Stores encrypted user records with IVs and authentication tags

### Step 5: Run the Application

```bash
python3 main.py
```

The Flask server will start on `http://localhost:5000` by default.

## API Endpoints

### Authentication

#### Register a New User
```bash
POST /register
Content-Type: application/json

{
  "username": "john_doe",
  "password": "secure_password_123"
}
```

**Response (201 Created)**:
```json
{
  "message": "User registered successfully",
  "user_id": 1
}
```

#### Login
```bash
POST /login
Content-Type: application/json

{
  "username": "john_doe",
  "password": "secure_password_123"
}
```

**Response (200 OK)**:
```json
{
  "message": "Logged in successfully",
  "token": "1:vault:read,vault:write,token:manage,audit:read,sqli:demo:1718702400.abc123def456..."
}
```

### Data Vault

#### Store an Encrypted Record
```bash
POST /vault
Authorization: Bearer <token>
Content-Type: application/json

{
  "record_id": "user_profile_123",
  "content": "Sensitive user data like SSN, credit card, etc."
}
```

**Response (201 Created)**:
```json
{
  "message": "Record stored successfully",
  "record_id": "user_profile_123"
}
```

#### Retrieve an Encrypted Record
```bash
GET /vault/<record_id>
Authorization: Bearer <token>
```

**Response (200 OK)**:
```json
{
  "record_id": "user_profile_123",
  "content": "Sensitive user data like SSN, credit card, etc."
}
```

#### Delete an Encrypted Record
```bash
DELETE /vault/<record_id>
Authorization: Bearer <token>
```

**Response (200 OK)**:
```json
{
  "message": "Record deleted successfully"
}
```

### Security Dashboard

#### Create a New Capability Token
```bash
POST /dashboard/tokens
Authorization: Bearer <token>
Content-Type: application/json

{
  "user_id": 1,
  "scope": "vault:read,vault:write",
  "expires_in_seconds": 3600
}
```

**Response (201 Created)**:
```json
{
  "message": "Token created successfully",
  "token": "1:vault:read,vault:write:1718702400.abc123def456..."
}
```

#### List User's Capability Tokens
```bash
GET /dashboard/tokens
Authorization: Bearer <token>
```

**Response (200 OK)**:
```json
[
  {
    "id": 1,
    "scope": "vault:read,vault:write,token:manage,audit:read,sqli:demo",
    "expires_at": 1718702400,
    "revoked": false
  }
]
```

#### Revoke a Capability Token
```bash
PUT /dashboard/tokens/<token_id>
Authorization: Bearer <token>
```

**Response (200 OK)**:
```json
{
  "message": "Token revoked successfully"
}
```

#### View Audit Logs
```bash
GET /dashboard/auditlogs
Authorization: Bearer <token>
```

**Response (200 OK)**:
```json
[
  {
    "id": 1,
    "user_id": 1,
    "token_id": 1,
    "timestamp": 1718702400,
    "operation": "Store Record",
    "outcome": "Success"
  },
  {
    "id": 2,
    "user_id": 1,
    "token_id": 1,
    "timestamp": 1718702401,
    "operation": "Retrieve Record",
    "outcome": "Success"
  }
]
```

### SQL Injection Demo

#### Test SQL Injection Protection
```bash
POST /sqli-demo
Authorization: Bearer <token>
Content-Type: application/json

{
  "input": "'; DROP TABLE users; --"
}
```

**Response (200 OK)**:
```json
{
  "message": "Input received: '; DROP TABLE users; --'\nSanitized input: ' DROP TABLE users '\n\nSQL Injection is prevented because all database operations use parameterized queries, meaning user input is treated as data, not executable code. Malicious inputs like ' OR 1=1 -- are safely handled and will not alter query logic."
}
```

## Testing SQL Injection Protection

The system provides a dedicated endpoint to demonstrate SQL injection protection. Here are several test cases:

### Test Case 1: Classic SQL Injection
```bash
curl -X POST http://localhost:5000/sqli-demo \
  -H "Authorization: Bearer <your_token>" \
  -H "Content-Type: application/json" \
  -d '{"input": "'\'' OR 1=1 --"}'
```

**Expected Result**: The malicious input is sanitized and safely handled. The system explains that parameterized queries prevent the injection from altering query logic.

### Test Case 2: Time-Based Blind SQL Injection
```bash
curl -X POST http://localhost:5000/sqli-demo \
  -H "Authorization: Bearer <your_token>" \
  -H "Content-Type: application/json" \
  -d '{"input": "'; WAITFOR DELAY '\''00:00:05'\''; --"}'
```

**Expected Result**: The input is sanitized and the system confirms that parameterized queries prevent this attack.

### Test Case 3: Union-Based SQL Injection
```bash
curl -X POST http://localhost:5000/sqli-demo \
  -H "Authorization: Bearer <your_token>" \
  -H "Content-Type: application/json" \
  -d '{"input": "UNION SELECT * FROM users --"}'
```

**Expected Result**: The input is safely handled and cannot alter the query structure.

## Security Highlights

### Why This System is Secure Against SQL Injection

1. **Parameterized Queries**: Every database query in `crud.py` uses SQLite's parameter binding with `?` placeholders. User input is never concatenated into SQL strings.

2. **Input Validation**: The `/sqli-demo` endpoint demonstrates input sanitization as a secondary defense layer.

3. **Capability Tokens**: All sensitive operations require valid, non-revoked tokens with appropriate scopes, preventing unauthorized access.

4. **Encryption at Rest**: Sensitive data in the vault is encrypted with AES-256-GCM, so even if the database is compromised, the data remains protected.

5. **Audit Logging**: Every operation is logged, enabling detection and investigation of suspicious activity.

### Example: Secure Query Implementation

Instead of this **vulnerable** approach:
```python
# VULNERABLE - DO NOT USE
query = f"SELECT * FROM users WHERE username = '{username}'"
cursor.execute(query)
```

This system uses **parameterized queries**:
```python
# SECURE - Used throughout this system
cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
```

With parameterized queries, the database driver treats the user input as data, not executable code, making SQL injection impossible.

## Configuration

Edit `config.py` to customize settings:

```python
class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'a_very_secret_key_for_dev')
    DATABASE_PATH = os.environ.get('DATABASE_PATH', 'database.db')
    ENCRYPTION_KEY = os.environ.get('ENCRYPTION_KEY', 'a_very_strong_aes_256_key_32_bytes_')
    TOKEN_EXPIRATION_SECONDS = 3600  # 1 hour
```

For production, set these environment variables:
```bash
export SECRET_KEY="your_strong_secret_key"
export DATABASE_PATH="/path/to/database.db"
export ENCRYPTION_KEY="your_32_byte_aes_key"
```

## Example Workflow

### 1. Register a User
```bash
curl -X POST http://localhost:5000/register \
  -H "Content-Type: application/json" \
  -d '{"username": "alice", "password": "alice_password"}'
```

### 2. Login
```bash
curl -X POST http://localhost:5000/login \
  -H "Content-Type: application/json" \
  -d '{"username": "alice", "password": "alice_password"}'
```

Save the returned `token` for subsequent requests.

### 3. Store an Encrypted Record
```bash
curl -X POST http://localhost:5000/vault \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"record_id": "ssn_123", "content": "123-45-6789"}'
```

### 4. Retrieve the Record
```bash
curl -X GET http://localhost:5000/vault/ssn_123 \
  -H "Authorization: Bearer <token>"
```

### 5. View Audit Logs
```bash
curl -X GET http://localhost:5000/dashboard/auditlogs \
  -H "Authorization: Bearer <token>"
```

### 6. Test SQL Injection Protection
```bash
curl -X POST http://localhost:5000/sqli-demo \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"input": "'\'' OR 1=1 --"}'
```

## Dependencies

- **Flask**: Web framework for building the REST API.
- **SQLAlchemy**: SQL toolkit and Object-Relational Mapping (ORM).
- **argon2-cffi**: Argon2 password hashing library.
- **cryptography**: Cryptographic recipes and primitives library for AES-256 encryption.

## Security Best Practices

1. **Never hardcode secrets**: Use environment variables for `SECRET_KEY`, `ENCRYPTION_KEY`, and `DATABASE_PATH`.
2. **Use HTTPS in production**: Ensure all API communication is encrypted in transit.
3. **Implement rate limiting**: Protect endpoints from brute-force attacks.
4. **Monitor audit logs**: Regularly review logs for suspicious activity.
5. **Rotate tokens regularly**: Implement token rotation policies.
6. **Keep dependencies updated**: Regularly update Python packages to patch security vulnerabilities.

## Troubleshooting

### Database Connection Error
Ensure the database file path is correct and the directory is writable.

### Token Validation Fails
Check that the token has not expired and that it has the required scope for the operation.

### Decryption Fails
Ensure the `ENCRYPTION_KEY` is consistent across runs. If the key changes, previously encrypted data cannot be decrypted.

## License

This project is provided as-is for educational and demonstration purposes.

## Support

For issues or questions, please refer to the project documentation or contact the development team.
