import os

class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY", "a_very_secret_key_for_dev")
    DATABASE_PATH = os.environ.get("DATABASE_PATH", "database.db")
    ENCRYPTION_KEY = os.environ.get("ENCRYPTION_KEY", "a_very_strong_aes_256_key_32_bytes_") # Must be 32 url-safe base64-encoded bytes
    TOKEN_EXPIRATION_SECONDS = 3600 # 1 hour
