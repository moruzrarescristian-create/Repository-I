import sqlite3
import time
from typing import List, Optional

from database import get_db
from models import User, CapabilityToken, AuditLog, DataVaultRecord
from security import encrypt_data, decrypt_data, hash_password, verify_password

# --- User Operations ---

def create_user(username, password) -> Optional[User]:
    hashed_pwd = hash_password(password)
    with get_db() as db:
        cursor = db.cursor()
        try:
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_pwd))
            db.commit()
            return User(id=cursor.lastrowid, username=username, password=hashed_pwd)
        except sqlite3.IntegrityError:
            return None # Username already exists

def get_user_by_username(username) -> Optional[User]:
    with get_db() as db:
        cursor = db.cursor()
        cursor.execute("SELECT id, username, password FROM users WHERE username = ?", (username,))
        user_data = cursor.fetchone()
        if user_data:
            return User(**user_data)
        return None

def get_user_by_id(user_id) -> Optional[User]:
    with get_db() as db:
        cursor = db.cursor()
        cursor.execute("SELECT id, username, password FROM users WHERE id = ?", (user_id,))
        user_data = cursor.fetchone()
        if user_data:
            return User(**user_data)
        return None

# --- Capability Token Operations ---

def create_capability_token(user_id: int, hashed_token: str, scope: str, expires_at: int) -> CapabilityToken:
    with get_db() as db:
        cursor = db.cursor()
        cursor.execute(
            "INSERT INTO capability_tokens (user_id, hashed_token, scope, expires_at) VALUES (?, ?, ?, ?)",
            (user_id, hashed_token, scope, expires_at)
        )
        db.commit()
        return CapabilityToken(id=cursor.lastrowid, user_id=user_id, hashed_token=hashed_token, scope=scope, expires_at=expires_at, revoked=False)

def get_capability_token_by_hashed_token(hashed_token: str) -> Optional[CapabilityToken]:
    with get_db() as db:
        cursor = db.cursor()
        cursor.execute("SELECT id, user_id, hashed_token, scope, expires_at, revoked FROM capability_tokens WHERE hashed_token = ?", (hashed_token,))
        token_data = cursor.fetchone()
        if token_data:
            return CapabilityToken(**token_data)
        return None

def revoke_capability_token(token_id: int) -> bool:
    with get_db() as db:
        cursor = db.cursor()
        cursor.execute("UPDATE capability_tokens SET revoked = 1 WHERE id = ?", (token_id,))
        db.commit()
        return cursor.rowcount > 0

def get_user_tokens(user_id: int) -> List[CapabilityToken]:
    with get_db() as db:
        cursor = db.cursor()
        cursor.execute("SELECT id, user_id, hashed_token, scope, expires_at, revoked FROM capability_tokens WHERE user_id = ?", (user_id,))
        return [CapabilityToken(**row) for row in cursor.fetchall()]

# --- Audit Log Operations ---

def add_audit_log(user_id: Optional[int], token_id: Optional[int], operation: str, outcome: str):
    with get_db() as db:
        cursor = db.cursor()
        timestamp = int(time.time())
        cursor.execute(
            "INSERT INTO audit_logs (user_id, token_id, timestamp, operation, outcome) VALUES (?, ?, ?, ?, ?)",
            (user_id, token_id, timestamp, operation, outcome)
        )
        db.commit()

def get_audit_logs(limit: int = 100) -> List[AuditLog]:
    with get_db() as db:
        cursor = db.cursor()
        cursor.execute("SELECT id, user_id, token_id, timestamp, operation, outcome FROM audit_logs ORDER BY timestamp DESC LIMIT ?", (limit,))
        return [AuditLog(**row) for row in cursor.fetchall()]

# --- Data Vault Operations ---

def store_encrypted_record(user_id: int, record_id: str, data: str) -> Optional[DataVaultRecord]:
    iv, ciphertext, tag = encrypt_data(data)

    with get_db() as db:
        cursor = db.cursor()
        try:
            cursor.execute(
                "INSERT INTO data_vault (user_id, record_id, encrypted_data, iv, tag) VALUES (?, ?, ?, ?, ?)",
                (user_id, record_id, ciphertext, iv, tag)
            )
            db.commit()
            return DataVaultRecord(id=cursor.lastrowid, user_id=user_id, record_id=record_id, encrypted_data=ciphertext, iv=iv, tag=tag)
        except sqlite3.IntegrityError:
            return None # Record ID already exists for this user

def retrieve_encrypted_record(user_id: int, record_id: str) -> Optional[str]:
    with get_db() as db:
        cursor = db.cursor()
        cursor.execute("SELECT encrypted_data, iv, tag FROM data_vault WHERE user_id = ? AND record_id = ?", (user_id, record_id))
        record_data = cursor.fetchone()
        if record_data:
            try:
                plaintext = decrypt_data(record_data["iv"], record_data["encrypted_data"], record_data["tag"])
                return plaintext
            except Exception as e:
                print(f"Decryption failed: {e}")
                return None
        return None

def delete_encrypted_record(user_id: int, record_id: str) -> bool:
    with get_db() as db:
        cursor = db.cursor()
        cursor.execute("DELETE FROM data_vault WHERE user_id = ? AND record_id = ?", (user_id, record_id))
        db.commit()
        return cursor.rowcount > 0
