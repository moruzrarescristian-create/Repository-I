import sqlite3
from config import Config

DATABASE = Config.DATABASE_PATH

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as db:
        cursor = db.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            );
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS capability_tokens (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                hashed_token TEXT UNIQUE NOT NULL,
                scope TEXT NOT NULL,
                expires_at INTEGER NOT NULL,
                revoked BOOLEAN NOT NULL DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users (id)
            );
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                token_id INTEGER,
                timestamp INTEGER NOT NULL,
                operation TEXT NOT NULL,
                outcome TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (token_id) REFERENCES capability_tokens (id)
            );
        """)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS data_vault (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                record_id TEXT UNIQUE NOT NULL,
                encrypted_data BLOB NOT NULL,
                iv BLOB NOT NULL,
                tag BLOB NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users (id)
            );
        """)
        db.commit()

if __name__ == '__main__':
    init_db()
    print("Database initialized.")
