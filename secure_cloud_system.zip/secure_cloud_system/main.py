from flask import Flask, request, jsonify, g
from functools import wraps
import time
import re

from config import Config
from database import init_db, get_db
from security import token_manager, hash_password, verify_password
from crud import (
    create_user, get_user_by_username, create_capability_token,
    get_capability_token_by_hashed_token, revoke_capability_token,
    get_user_tokens, add_audit_log, get_audit_logs,
    store_encrypted_record, retrieve_encrypted_record, delete_encrypted_record
)

app = Flask(__name__)
app.config.from_object(Config)

# Initialize database
with app.app_context():
    init_db()

# --- Helper Functions and Decorators ---

def get_current_user():
    # In a real app, this would come from a session or JWT
    # For this demo, we'll assume user_id is passed with token payload
    return g.user_id if hasattr(g, 'user_id') else None

def token_required(scope: str):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            auth_header = request.headers.get("Authorization")
            if not auth_header or not auth_header.startswith("Bearer "):
                add_audit_log(user_id=get_current_user(), token_id=None, operation=f"Access {request.path}", outcome="Failure: Missing or invalid Authorization header")
                return jsonify({"message": "Authorization token is missing or invalid!"}), 401

            token = auth_header.split(" ")[1]
            token_data = token_manager.verify_token(token)

            if not token_data:
                add_audit_log(user_id=get_current_user(), token_id=None, operation=f"Access {request.path}", outcome="Failure: Invalid or expired token")
                return jsonify({"message": "Token is invalid or expired!"}), 401

            # Check if token is revoked in DB
            db_token = get_capability_token_by_hashed_token(token_manager.hash_token(token))
            if not db_token or db_token.revoked:
                add_audit_log(user_id=token_data["user_id"], token_id=db_token.id if db_token else None, operation=f"Access {request.path}", outcome="Failure: Token revoked")
                return jsonify({"message": "Token has been revoked!"}), 401

            if scope not in token_data["scope"]:
                add_audit_log(user_id=token_data["user_id"], token_id=db_token.id, operation=f"Access {request.path}", outcome="Failure: Insufficient scope")
                return jsonify({"message": "Insufficient token scope!"}), 403

            g.user_id = token_data["user_id"]
            g.token_id = db_token.id
            return f(*args, **kwargs)
        return decorated
    return decorator

# --- User Authentication ---

@app.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    if not username or not password:
        add_audit_log(user_id=None, token_id=None, operation="Register", outcome="Failure: Missing username or password")
        return jsonify({"message": "Username and password are required"}), 400

    user = create_user(username, password)
    if user:
        add_audit_log(user_id=user.id, token_id=None, operation="Register", outcome="Success")
        return jsonify({"message": "User registered successfully", "user_id": user.id}), 201
    else:
        add_audit_log(user_id=None, token_id=None, operation="Register", outcome="Failure: Username already exists")
        return jsonify({"message": "Username already exists"}), 409

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    user = get_user_by_username(username)
    if not user or not verify_password(user.password, password):
        add_audit_log(user_id=user.id if user else None, token_id=None, operation="Login", outcome="Failure: Invalid credentials")
        return jsonify({"message": "Invalid credentials"}), 401

    # For simplicity, we generate a token with broad scope on login. In a real app, scopes would be more granular.
    new_token = token_manager.generate_token(user.id, "vault:read,vault:write,token:manage,audit:read,sqli:demo")
    hashed_new_token = token_manager.hash_token(new_token)
    expires_at = int(time.time()) + Config.TOKEN_EXPIRATION_SECONDS
    create_capability_token(user.id, hashed_new_token, "vault:read,vault:write,token:manage,audit:read,sqli:demo", expires_at)

    add_audit_log(user_id=user.id, token_id=None, operation="Login", outcome="Success")
    return jsonify({"message": "Logged in successfully", "token": new_token}), 200

# --- Data Vault Endpoints ---

@app.route("/vault", methods=["POST"])
@token_required("vault:write")
def store_record():
    data = request.get_json()
    record_id = data.get("record_id")
    content = data.get("content")

    if not record_id or not content:
        add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Store Record", outcome="Failure: Missing record_id or content")
        return jsonify({"message": "Record ID and content are required"}), 400

    record = store_encrypted_record(g.user_id, record_id, content)
    if record:
        add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Store Record", outcome="Success")
        return jsonify({"message": "Record stored successfully", "record_id": record.record_id}), 201
    else:
        add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Store Record", outcome="Failure: Record ID already exists")
        return jsonify({"message": "Record ID already exists or other error"}), 409

@app.route("/vault/<record_id>", methods=["GET"])
@token_required("vault:read")
def retrieve_record(record_id):
    content = retrieve_encrypted_record(g.user_id, record_id)
    if content:
        add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Retrieve Record", outcome="Success")
        return jsonify({"record_id": record_id, "content": content}), 200
    else:
        add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Retrieve Record", outcome="Failure: Record not found or decryption failed")
        return jsonify({"message": "Record not found or could not be decrypted"}), 404

@app.route("/vault/<record_id>", methods=["DELETE"])
@token_required("vault:write")
def delete_record(record_id):
    if delete_encrypted_record(g.user_id, record_id):
        add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Delete Record", outcome="Success")
        return jsonify({"message": "Record deleted successfully"}), 200
    else:
        add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Delete Record", outcome="Failure: Record not found")
        return jsonify({"message": "Record not found"}), 404

# --- Security Dashboard Endpoints ---

@app.route("/dashboard/tokens", methods=["POST"])
@token_required("token:manage")
def create_token():
    data = request.get_json()
    target_user_id = data.get("user_id", g.user_id) # Allow creating tokens for other users if admin
    scope = data.get("scope", "vault:read")
    expires_in = data.get("expires_in_seconds", Config.TOKEN_EXPIRATION_SECONDS)

    # In a real app, check if g.user_id has admin rights to create tokens for other users
    if target_user_id != g.user_id: # Simple check for now
        add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Create Token", outcome="Failure: Unauthorized to create token for another user")
        return jsonify({"message": "Unauthorized to create token for another user"}), 403

    new_token = token_manager.generate_token(target_user_id, scope, expires_in)
    hashed_new_token = token_manager.hash_token(new_token)
    expires_at = int(time.time()) + expires_in
    create_capability_token(target_user_id, hashed_new_token, scope, expires_at)

    add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Create Token", outcome="Success")
    return jsonify({"message": "Token created successfully", "token": new_token}), 201

@app.route("/dashboard/tokens", methods=["GET"])
@token_required("token:manage")
def list_tokens():
    tokens = get_user_tokens(g.user_id)
    add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="List Tokens", outcome="Success")
    return jsonify([
        {"id": t.id, "scope": t.scope, "expires_at": t.expires_at, "revoked": t.revoked}
        for t in tokens
    ]), 200

@app.route("/dashboard/tokens/<int:token_id>", methods=["PUT"])
@token_required("token:manage")
def revoke_token(token_id):
    # Ensure the token belongs to the current user or user has admin rights
    token_to_revoke = get_capability_token_by_hashed_token(token_manager.hash_token(request.headers.get("Authorization").split(" ")[1])) # This is a simplification, should get token by ID
    if not token_to_revoke or token_to_revoke.user_id != g.user_id:
        add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Revoke Token", outcome="Failure: Unauthorized to revoke token")
        return jsonify({"message": "Unauthorized to revoke this token"}), 403

    if revoke_capability_token(token_id):
        add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Revoke Token", outcome="Success")
        return jsonify({"message": "Token revoked successfully"}), 200
    else:
        add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="Revoke Token", outcome="Failure: Token not found")
        return jsonify({"message": "Token not found"}), 404

@app.route("/dashboard/auditlogs", methods=["GET"])
@token_required("audit:read")
def list_audit_logs():
    logs = get_audit_logs()
    add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="List Audit Logs", outcome="Success")
    return jsonify([
        {"id": l.id, "user_id": l.user_id, "token_id": l.token_id, "timestamp": l.timestamp, "operation": l.operation, "outcome": l.outcome}
        for l in logs
    ]), 200

# --- SQL Injection Demo Endpoint ---

@app.route("/sqli-demo", methods=["POST"])
@token_required("sqli:demo")
def sqli_demo():
    data = request.get_json()
    user_input = data.get("input", "")

    # Input validation and sanitization (Layer 1 of defense)
    # For demonstration, we'll strip common SQL injection characters.
    # In a real application, this would be more sophisticated or rely on ORM/DB driver.
    sanitized_input = re.sub(r"[;'"]", "", user_input) # Remove semicolons, single quotes, double quotes

    # Simulate a database query that *would* be vulnerable if not parameterized
    # But here, we just show the sanitized input and explain the protection.
    message = f"Input received: \'{user_input}\'\nSanitized input: \'{sanitized_input}\'\n\nSQL Injection is prevented because all database operations use parameterized queries, meaning user input is treated as data, not executable code. Malicious inputs like \' OR 1=1 -- are safely handled and will not alter query logic."
    add_audit_log(user_id=g.user_id, token_id=g.token_id, operation="sqli_demo", outcome="Success: Input blocked by parameterized query design")
    return jsonify({"message": message}), 200


if __name__ == "__main__":
    app.run(debug=True)
