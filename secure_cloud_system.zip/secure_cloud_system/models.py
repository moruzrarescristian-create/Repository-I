from dataclasses import dataclass
from typing import Optional

@dataclass
class User:
    id: Optional[int]
    username: str
    password: str  # Hashed password

@dataclass
class CapabilityToken:
    id: Optional[int]
    user_id: int
    hashed_token: str
    scope: str
    expires_at: int
    revoked: bool

@dataclass
class AuditLog:
    id: Optional[int]
    user_id: Optional[int]
    token_id: Optional[int]
    timestamp: int
    operation: str
    outcome: str

@dataclass
class DataVaultRecord:
    id: Optional[int]
    user_id: int
    record_id: str
    encrypted_data: bytes
    iv: bytes
    tag: bytes
