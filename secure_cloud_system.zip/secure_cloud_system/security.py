import os
import hashlib
import hmac
from base64 import urlsafe_b64encode, urlsafe_b64decode
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from argon2 import PasswordHasher
from datetime import datetime, timedelta

from config import Config

# Ensure ENCRYPTION_KEY is properly formatted (32 bytes for AES-256)
# In a real application, this key should be securely generated and managed.
# For demonstration, we'll ensure it's 32 bytes by hashing the provided string.
if len(Config.ENCRYPTION_KEY) < 32:
    MASTER_AES_KEY = hashlib.sha256(Config.ENCRYPTION_KEY.encode()).digest()
else:
    MASTER_AES_KEY = Config.ENCRYPTION_KEY.encode()[:32]

# --- Encryption/Decryption (AES-256 GCM) ---

def encrypt_data(data: str) -> tuple[bytes, bytes, bytes]:
    # Generate a unique IV for each encryption
    iv = os.urandom(12)  # GCM recommended IV size is 12 bytes
    cipher = Cipher(algorithms.AES256(MASTER_AES_KEY), modes.GCM(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(data.encode()) + encryptor.finalize()
    return iv, ciphertext, encryptor.tag

def decrypt_data(iv: bytes, ciphertext: bytes, tag: bytes) -> str:
    cipher = Cipher(algorithms.AES256(MASTER_AES_KEY), modes.GCM(iv), backend=default_backend())
    decryptor = cipher.decryptor()
    decryptor.authenticate_associated_data(b"") # No associated data
    plaintext = decryptor.update(ciphertext) + decryptor.finalize()
    return plaintext.decode()

# --- Password Hashing (Argon2) ---
ph = PasswordHasher()

def hash_password(password: str) -> str:
    return ph.hash(password)

def verify_password(hashed_password: str, password: str) -> bool:
    try:
        ph.verify(hashed_password, password)
        return True
    except Exception:
        return False

# --- Capability Token Management ---

class TokenManager:
    def __init__(self, secret_key: str):
        self.secret_key = secret_key.encode()

    def generate_token(self, user_id: int, scope: str, expires_in_seconds: int = Config.TOKEN_EXPIRATION_SECONDS) -> str:
        payload = f"{user_id}:{scope}:{int(datetime.now().timestamp() + expires_in_seconds)}"
        signature = hmac.new(self.secret_key, payload.encode(), hashlib.sha256).hexdigest()
        return f"{payload}.{signature}"

    def verify_token(self, token: str) -> dict | None:
        try:
            payload, signature = token.rsplit(".", 1)
            user_id_str, scope, expiry_str = payload.split(":")

            expected_signature = hmac.new(self.secret_key, payload.encode(), hashlib.sha256).hexdigest()

            if not hmac.compare_digest(expected_signature, signature):
                return None # Invalid signature

            if datetime.now().timestamp() > int(expiry_str):
                return None # Token expired

            return {"user_id": int(user_id_str), "scope": scope, "expires": int(expiry_str)}
        except Exception:
            return None

    def hash_token(self, token: str) -> str:
        return hashlib.sha256(token.encode()).hexdigest()

token_manager = TokenManager(Config.SECRET_KEY)
