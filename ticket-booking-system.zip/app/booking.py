import uuid
import redis
r = redis.Redis(host="redis", port=6379)

def lock_seat(seat_no):
    return r.set(f"seat:{seat_no}", "locked", nx=True, ex=300)

def generate_ticket_uuid():
    return str(uuid.uuid4())
