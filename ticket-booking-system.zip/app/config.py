DATABASE_URL = "postgresql://postgres:postgres@db:5432/ticketdb"
REDIS_HOST = "redis"
SECRET_KEY = "supersecretkey"
ALGORITHM = "HS256"
