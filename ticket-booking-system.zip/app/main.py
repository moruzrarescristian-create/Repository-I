from fastapi import FastAPI
app = FastAPI(title="Cloud Ticket Booking System")

@app.get("/")
def root():
    return {"status":"running"}
