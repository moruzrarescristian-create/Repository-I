import qrcode

def generate_qr(ticket_uuid):
    img = qrcode.make(ticket_uuid)
    path = f"tickets/{ticket_uuid}.png"
    img.save(path)
    return path
