from pydantic import BaseModel

class UserCreate(BaseModel):
    email: str
    password: str

class BookingRequest(BaseModel):
    user_id: int
    ticket_id: int
